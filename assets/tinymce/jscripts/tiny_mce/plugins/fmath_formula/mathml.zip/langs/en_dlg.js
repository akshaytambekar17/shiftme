//-------------------------------------------------------------
//	Created by: Ionel Alexandru 
//	Mail: ionel.alexandru@gmail.com
//	Site: www.fmath.info
//---------------------------------------------------------------


tinyMCE.addI18n('en.fmath_formula_dlg',{
	title : 'Add a MathML Formula'
});
